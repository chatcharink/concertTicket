Couldn't find the requested file /minified/html5-qrcode.min.js in html5-qrcode.;
